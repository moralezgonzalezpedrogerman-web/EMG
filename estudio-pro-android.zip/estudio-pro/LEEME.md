# Estudio Pro v0.2 – proyecto Android (Capacitor)

## Requisitos
- Node.js 18+  - Android Studio (con SDK Android 34)  - JDK 17

## Pasos
1. En esta carpeta:  npm install
2. npx cap add android
3. Abre  android/app/src/main/AndroidManifest.xml  y dentro de <manifest> agrega:
     <uses-permission android:name="android.permission.RECORD_AUDIO" />
     <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
4. npx cap sync android
5. npx cap open android  → en Android Studio: Build > Build APK(s)
6. Instala el APK en tu celular (activa "instalar apps desconocidas").

## Nota
Cada vez que edites www/index.html corre:  npx cap sync android
La descarga de WAV puede necesitar el plugin @capacitor/filesystem; es lo primero que conviene agregar.

## Hoja de ruta (para superar a BandLab)
1. Guardar/abrir proyectos
2. Edición de clips: cortar, mover, fades, loops
3. Autotune (detección de tono + corrección a escala)
4. Más efectos: chorus, flanger, de-esser, puerta de ruido
5. Master con medidor de loudness (LUFS) y presets por plataforma
6. Plugin nativo de audio (Oboe) para baja latencia al grabar

## Compilar en la nube (sin Android Studio)
Sube esta carpeta a un repositorio de GitHub. El archivo .github/workflows/build-apk.yml
compila solo: ve a Actions > Build APK > descarga "EstudioPro-APK" y instala el APK.

## v0.3
Autotune ajustable (tono, escala, fuerza, velocidad), cambiador de voz, afinador en vivo,
filtro paramétrico, de-esser, auto-pan y 27 presets de masterización.
Formatos: los que soporte el Android del celular (mp3, wav, flac, ogg, m4a/aac, opus, amr, mp4/3gp como audio).

## v0.4
Grabación mejorada (con el resto sonando, cuenta regresiva, metrónomo, medidor de nivel, compensación de latencia),
ecos ajustables (normal, ping-pong, slapback, cinta, dub), reverb ajustable, flanger, phaser, auto-wah, vibrato,
filtro DJ, compresor avanzado, simulador de micrófono, reductor de ruido espectral, puerta de ruido, quitar zumbido,
combos de efectos (con guardado propio) y exportación en WAV 16/24/32, WebM/OGG Opus y M4A AAC (según el Android).
No incluye MP3/FLAC: necesitan una librería codificadora empaquetada.

## v0.5
Guardar/abrir proyectos (IndexedDB), exportación FLAC 16/24 bits y MP3 (lamejs se copia solo en npm install),
botón "Guardar / compartir" (plugins @capacitor/filesystem y @capacitor/share), más filtros (resonancia, pasa-banda,
peine, vocal A-E-I-O-U), 5 tipos de distorsión, velocidades de modulación, bombeo, ancho estéreo por pista,
armonías/doblar voz, repetir, invertir fase, y master con ancho estéreo, techo del limitador, corte de sub-graves
y compresor ajustable. 42 presets de masterización.

## v0.6
Línea de tiempo con cabezal (toca la onda para saltar), dividir clips, deshacer/rehacer, volumen en LUFS reales
(medidor en vivo y normalización al exportar), generador de ritmos (Trap, Reguetón, Boom bap, House, Cumbia, Rock, Drill)
con bajo 808, fondos (lluvia, vinilo, viento, océano, ruido), tempo sin cambiar tono, detector de BPM, nivelador de voz,
recorte de silencios y curvas de ecualizador en pantalla.

## v0.7
Pestaña "Loops": 22 géneros × 20 bases × 30 loops (13 200 loops) generados dentro de la app, sin archivos de audio.
Cada base fija tempo, tono, escala y acordes; sus 30 loops combinan entre sí (batería, percusión, bajo, armonía,
melodías, riff, pad, riser y 8 secciones de mezcla). Suenan a sintetizador.

## v0.8
Pestaña "IA" (asistente de mezcla): mide voz e instrumental reales (espectro en 22 bandas, volumen tipo LUFS,
tono, tempo, tonalidad), calcula 3 opciones para que la voz no quede tapada (volumen, EQ de bolsillo en el
instrumental, ducking solo cuando canta la voz, cadena de voz, reverb/eco al tempo) y comprueba el resultado
renderizando el audio real. Incluye EQ de bolsillo por pista, ducking, autotune sugerido por la tonalidad
detectada y reducción de ruido recomendada por la relación señal/ruido.

## v0.9
- Biblioteca de loops v2: más variedad entre bases (patrones de batería/bajo/acordes generados por gramática, personalidad
  de timbre, humanización, swing propio), sonido estéreo con reverb, sidechain y compresor de mezcla.
- Pestaña "Instr.": teclado virtual (escala bloqueada, acordes de 1 dedo, grabación cuantizada), secuenciador de patrones,
  diseñador de instrumentos y sampler (importa un sonido y se reparte por el teclado).
- Pestaña "Ideas": la IA analiza el proyecto (tempo, tonalidad, acordes por compás, huecos de ritmo, espacio en
  frecuencias, cuándo canta la voz) y genera ideas para el instrumento elegido, con registro de auditoría.
- "Mi biblioteca": registra ideas, pistas y bases con su registro de auditoría (IndexedDB).
- Workflow: encuentra package.json aunque esté en una subcarpeta y avisa con mensajes claros si falta algo.

## v1.0
- Pestaña "Vivo" (estudio en vivo, estilo BandLab): elige una base, ajusta el tempo (−/+/Tap) y activa o desactiva
  los 30 loops mientras suena. Los loops se generan al tempo exacto (sin deformar el sonido) y entran siempre
  alineados al compás. Metrónomo que se enciende y apaga en vivo, cuenta de 0/1/2/4 compases, entrada de loops
  al compás / al tiempo / al instante, opción de grabar tu micrófono a la vez y de tocar con el proyecto sonando.
  Al parar, tus activaciones y desactivaciones se guardan como una pista por loop.
- El metrónomo del grabador de Pistas ahora usa el mismo reloj de audio preciso (sin deriva).
- Workflow: si en el repositorio solo está el zip, lo descomprime solo.
